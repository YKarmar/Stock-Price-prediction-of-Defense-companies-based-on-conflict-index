import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.colors import LogNorm


def main():
    file_path = '1997-01-01-2024-01-01-Middle_East.csv'
    col_to_read = ["event_date", "year", "disorder_type", "event_type", "sub_event_type"]
    df = pd.read_csv(file_path, usecols=col_to_read)

    # Convert 'event_date' to datetime format
    df['event_date'] = pd.to_datetime(df['event_date'], format='%d %B %Y')
    start_year = df['year'].min()
    end_year = df['year'].max()-1

    month = {}
    for i in range(start_year, end_year + 1):
        for x in range(1, 13):
            month[(i, x)] = 0

    for i in range(len(df['year'])):
        if start_year <= df['year'][i] <= end_year:
            month[(df['year'][i], df['event_date'][i].month)] += 1

    violence_in_Middle_East = list(range(start_year, end_year + 1))
    event_matrix = np.zeros((len(violence_in_Middle_East), 12))

    for i in range(len(violence_in_Middle_East)):
        for j in range(1, 13):
            event_matrix[i, j - 1] = month[(violence_in_Middle_East[i], j)]

    month_names = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October',
                   'November', 'December']

    plt.figure(figsize=(12, 5))
    sns.heatmap(event_matrix, annot=True, fmt='g', xticklabels=month_names, yticklabels=violence_in_Middle_East)
    plt.xlabel('Month')
    plt.ylabel('Year')
    plt.title('Explosion/Remote Violence Event Count Heatmap in the Middle East')
    plt.show()


def brain():
    file_path = '1997-01-01-2024-01-01-Middle_East.csv'
    col_to_read = ["event_date", "year", "disorder_type", "event_type", "sub_event_type"]
    df = pd.read_csv(file_path, usecols=col_to_read)

    df['year'] = df['year'].astype(str)
    year_counts = df['year'].value_counts()
    year_counts = year_counts.sort_index()

    # Plotting
    plt.bar(year_counts.index, year_counts.values, color='skyblue')
    plt.xlabel('Year')
    plt.ylabel('Explosions/Remote Violence Events')
    plt.title('Occurrences of Explosions/Remote Violence Events Per Year in the Middle East')
    plt.show()


if __name__ == "__main__":
    main()
