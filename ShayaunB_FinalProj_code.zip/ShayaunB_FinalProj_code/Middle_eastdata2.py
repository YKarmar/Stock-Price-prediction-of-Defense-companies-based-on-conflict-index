import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.colors import LogNorm


def Heatmap_allConflict():
    """
   Takes in the ACLED data for the Middle East of ALL event types and plots a heatmap of the number of events per month for each year.
   :return: A HEATMAP graph of the number of events per month for each year.
   """
    file_path = 'All_Conflict_Middle_East.csv'
    col_to_read = ["event_date", "year", "disorder_type", "event_type", "sub_event_type"]
    df = pd.read_csv(file_path, usecols=col_to_read)

    # Convert 'event_date' to datetime format
    df['event_date'] = pd.to_datetime(df['event_date'], format='%d %B %Y')
    start_year = df['year'].min()
    end_year = df['year'].max()

    month = {}
    for i in range(start_year, end_year + 1):
        for x in range(1, 13):
            month[(i, x)] = 0

    for i in range(len(df['year'])):
        if start_year <= df['year'][i] <= end_year:
            month[(df['year'][i], df['event_date'][i].month)] += 1

    violence_in_Middle_East = list(range(start_year, end_year + 1))
    event_matrix = np.zeros((len(violence_in_Middle_East), 12))

    for i in range(len(violence_in_Middle_East)):
        for j in range(1, 13):
            event_matrix[i, j - 1] = month[(violence_in_Middle_East[i], j)]

    month_names = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October',
                   'November', 'December']

    plt.figure(figsize=(12, 5))
    sns.heatmap(event_matrix, annot=True, fmt='g', xticklabels=month_names, yticklabels=violence_in_Middle_East)
    plt.xlabel('Month')
    plt.ylabel('Year')
    plt.title('All Conflict Count Heatmap in the Middle East')
    plt.show()


def ExplosiveEvents_Middle_E():
    """
    This function reads the conflict data in the Middle East and plots the total number of EXPLOSIVE/Remeote violence events per year as a bar graph
    :return: EXPLOSIVE/Remeote violence events per year as a bar graph
    """
    file_path = 'All_Conflict_Middle_East.csv'
    col_to_read = ["event_date", "year", "disorder_type", "event_type", "sub_event_type"]
    df = pd.read_csv(file_path, usecols=col_to_read)

    df['year'] = df['year'].astype(str)
    year_counts = df['year'].value_counts()
    year_counts = year_counts.sort_index()

    # Plotting
    plt.bar(year_counts.index, year_counts.values, color='skyblue')
    plt.xlabel('Year')
    plt.ylabel('Explosions/Remote Violence Events')
    plt.title('Total Conflict Events Per Year in the Middle East')
    plt.show()


def eventtype_heatmap_all():
    """
     This function reads the conflict data in the Middle East and plots a heatmap for EACH event seperately on its on heatmap graph for each year in moths.
    :return:
    """
    file_path = 'All_Conflict_Middle_East.csv'
    col_to_read = ["event_date", "year", "disorder_type", "event_type", "sub_event_type"]
    df = pd.read_csv(file_path, usecols=col_to_read)

    # Convert 'event_date' to datetime format
    df['event_date'] = pd.to_datetime(df['event_date'], format='%d %B %Y')
    start_year = df['year'].min()
    end_year = df['year'].max()

    event_types = ['Battles', 'Explosions/Remote violence', 'Protests', 'Riots', 'Violence against civilians']

    # Initialize a dictionary of matrices for each event type
    event_matrices = {event_type: np.zeros((end_year - start_year + 1, 12)) for event_type in event_types}

    for i in range(len(df)):
        if start_year <= df['year'][i] <= end_year:
            event_matrices[df['event_type'][i]][df['year'][i] - start_year, df['event_date'][i].month - 1] += 1

    month_names = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October',
                   'November', 'December']

    # Plot a separate heatmap for each event type
    for event_type, event_matrix in event_matrices.items():
        plt.figure(figsize=(12, 5))
        sns.heatmap(event_matrix, annot=True, fmt='g', xticklabels=month_names,
                    yticklabels=range(start_year, end_year + 1))
        plt.xlabel('Month')
        plt.ylabel('Year')
        plt.title(f'{event_type} Count Heatmap in the Middle East')
        plt.show()


def plot_event_type_counts():
    """
    This function reads the conflict data in the Middle East and plots the total number of events per year for each event type as a seperate bar graph.
    :return: seperate bar graph for each event type
    """
    file_path = 'All_Conflict_Middle_East.csv'
    col_to_read = ["event_date", "year", "disorder_type", "event_type", "sub_event_type"]
    df = pd.read_csv(file_path, usecols=col_to_read)

    df['year'] = df['year'].astype(str)

    # Define the event types you are interested in
    event_types = ['Battles', 'Explosions/Remote violence', 'Protests', 'Riots', 'Violence against civilians']

    # Set up subplots as a 2x3 grid
    fig, axes = plt.subplots(nrows=2, ncols=3, figsize=(15, 10))

    for i, event_type in enumerate(event_types):
        row, col = divmod(i, 3)
        type_counts = df[df['event_type'] == event_type]['year'].value_counts().sort_index()

        axes[row, col].bar(type_counts.index, type_counts.values, color='skyblue')
        axes[row, col].set_xlabel('Year')
        axes[row, col].set_ylabel(f'{event_type} Events')
        axes[row, col].set_title(f'Total {event_type} Events Per Year')

    plt.tight_layout()
    plt.show()


# def line_count_event():
#    file_path = 'All_Conflict_Middle_East.csv'
#    col_to_read = ["event_date", "year", "disorder_type", "event_type", "sub_event_type"]
#    df = pd.read_csv(file_path, usecols=col_to_read)
#
#    df['year'] = df['year'].astype(str)
#
#    # Define the event types you are interested in
#    event_types = ['Battles', 'Explosions/Remote violence', 'Protests', 'Riots', 'Violence against civilians']
#
#    # Set up the plot
#    plt.figure(figsize=(12, 6))
#
#    for event_type in event_types:
#       type_counts = df[df['event_type'] == event_type]['year'].value_counts().sort_index()
#       plt.plot(type_counts.index, type_counts.values, label=event_type, marker='o')
#
#    plt.xlabel('Year')
#    plt.ylabel('Number of Events')
#    plt.title('Total Events Per Year in the Middle East')
#    plt.legend()
#    plt.grid(True)
#    plt.show()
def line_count_event():
    """
   This function reads the conflict data in the Middle East and plots the total number of events per year.
   :return: a line graph representing the total number of events per year for each event type using daily data.
   """
    file_path = 'All_Conflict_Middle_East.csv'
    col_to_read = ["event_date", "year", "disorder_type", "event_type", "sub_event_type"]
    df = pd.read_csv(file_path, usecols=col_to_read)

    # Convert 'event_date' column to datetime format
    df['event_date'] = pd.to_datetime(df['event_date'], format='%d %B %Y')

    # Filter data for the specified time range (Jan 2017 - Dec 31, 2018)
    start_date = '2022-01-01'
    end_date = '2022-12-31'
    df = df[(df['event_date'] >= start_date) & (df['event_date'] <= end_date)]

    # Count total events per day
    daily_counts = df['event_date'].value_counts().sort_index()

    # Smooth the graph using a rolling window (e.g., 7 days for weekly smoothing)
    smoothed_counts = daily_counts.rolling(window=14, min_periods=1).mean()
    smoothed_counts2 = daily_counts.rolling(window=30, min_periods=1).mean()

    # Set up the plot
    plt.figure(figsize=(12, 6))

    # Plot total events per day with smoothed line
    # plt.plot(daily_counts.index, daily_counts.values, label='Daily Events', alpha=0.5, marker='o')
    plt.plot(smoothed_counts.index, smoothed_counts.values, label='14day avg', color='black', linewidth=1)
    plt.plot(smoothed_counts2.index, smoothed_counts2.values, label='30day avg', color='blue',
             linewidth=2)
    plt.xlabel('Date')
    plt.ylabel('Number of Events')
    plt.title('Total Daily Events in the Middle East (Jan 2017 - Dec 2018)')
    plt.legend()
    plt.grid(True)
    plt.show()


if __name__ == "__main__":
    # This script reads a CSV file containing conflict data in the Middle East and performs the following analyses:
    # To move on to the next function please close the graphs that pop up to move on!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!<--------------------IMportant !!!!!!!!!!!!!!!!!!!!!!!!

    Heatmap_allConflict()
    ExplosiveEvents_Middle_E()
    eventtype_heatmap_all()
    plot_event_type_counts()
    line_count_event()
