import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

def LMT():
    # Define file path and columns to read
    file_path = 'LMT.csv'
    col_to_read = ["Date", "Close"]

    # Read the data from the file
    df = pd.read_csv(file_path, usecols=col_to_read)

    # Convert 'Date' column to datetime format
    df['Date'] = pd.to_datetime(df['Date'])

    # Extract year from the 'Date' column
    df['Year'] = df['Date'].dt.year

    # Filter data for years up to 2019
    df = df[df['Year'] <= 2019]

    # Set up the plot
    plt.figure(figsize=(12, 6))

    # Group by year and plot the stock prices for each year
    for year, group in df.groupby('Year'):
        plt.plot(group['Date'], group['Close'], label=f'LMT - Year {year}')

    plt.xlabel('Date')
    plt.ylabel('Stock Price (Close)')
    plt.title('LMT Stock Close Prices Jan 2017 - Dec 2018')
    plt.legend()
    plt.grid(True)
    plt.show()

def RTX():
    # Define file path and columns to read
    file_path = 'RTX.csv'
    col_to_read = ["Date", "Close"]

    # Read the data from the file
    df = pd.read_csv(file_path, usecols=col_to_read)

    # Convert 'Date' column to datetime format
    df['Date'] = pd.to_datetime(df['Date'])

    # Extract year from the 'Date' column
    df['Year'] = df['Date'].dt.year

    # Filter data for years up to 2019
    df = df[df['Year'] <= 2018]

    # Set up the plot
    plt.figure(figsize=(12, 6))

    # Group by year and plot the stock prices for each year
    for year, group in df.groupby('Year'):
        plt.plot(group['Date'], group['Close'], label=f'RTX - Year {year}')

    plt.xlabel('Date')
    plt.ylabel('Stock Price (Close)')
    plt.title('RTX Stock Close Prices Jan 2017 - Dec 2018')
    plt.legend()
    plt.grid(True)
    plt.show()

def NOC():
    # Define file path and columns to read
    file_path = 'NOC.csv'
    col_to_read = ["Date", "Close"]

    # Read the data from the file
    df = pd.read_csv(file_path, usecols=col_to_read)

    # Convert 'Date' column to datetime format
    df['Date'] = pd.to_datetime(df['Date'])

    # Extract year from the 'Date' column
    df['Year'] = df['Date'].dt.year

    # Filter data for years up to 2019
    df = df[df['Year'] <= 2018]

    # Set up the plot
    plt.figure(figsize=(12, 6))

    # Group by year and plot the stock prices for each year
    for year, group in df.groupby('Year'):
        plt.plot(group['Date'], group['Close'], label=f'NOC - Year {year}')

    plt.xlabel('Date')
    plt.ylabel('Stock Price (Close)')
    plt.title('NOC Stock Close Prices Jan 2017 - Dec 2018')
    plt.legend()
    plt.grid(True)
    plt.show()



if __name__ == '__main__':
    LMT()
    RTX()
    NOC()
    print("Done")
